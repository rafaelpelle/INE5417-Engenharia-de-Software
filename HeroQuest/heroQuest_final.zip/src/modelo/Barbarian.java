package modelo;

public class Barbarian extends PlayableCharacter {

	private static final long serialVersionUID = -8284046323234351676L;
	
	public Barbarian() {
		super(8, 2, 3, 2);
	}
}