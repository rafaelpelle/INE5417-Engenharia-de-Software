package modelo;

public class ChaosWarrior extends Monster {

	private static final long serialVersionUID = 7458181011637387982L;

	public ChaosWarrior() {
		super(3, 3, 4, 4);
	}
}