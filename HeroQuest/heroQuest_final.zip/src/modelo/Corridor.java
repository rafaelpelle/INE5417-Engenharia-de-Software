package modelo;

public class Corridor extends Position {
	
	private static final long serialVersionUID = 6163108233308068056L;

	public Corridor(int row, int column) {
		super(row, column);
	}
}