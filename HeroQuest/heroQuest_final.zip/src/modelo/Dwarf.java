package modelo;

public class Dwarf extends PlayableCharacter {

	private static final long serialVersionUID = -5000713355090815680L;

	public Dwarf() {
		super(7, 3, 2, 2);
	}
}