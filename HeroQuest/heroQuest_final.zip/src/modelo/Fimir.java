package modelo;

public class Fimir extends Monster {
	
	private static final long serialVersionUID = 5353390972736151804L;

	public Fimir() {
		super(2, 3, 3, 3);
	}
}