package modelo;

public class Goblin extends Monster {
	
	private static final long serialVersionUID = -3684483016676624624L;

	public Goblin() {
		super(1, 1, 2, 1);
	}
}