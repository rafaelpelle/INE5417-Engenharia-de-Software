package modelo;

public class Monster extends Creature {

	private static final long serialVersionUID = 8724158042722706383L;

	public Monster(int body, int mind, int atk, int def) {
		super(body, mind, atk, def);
	}

}