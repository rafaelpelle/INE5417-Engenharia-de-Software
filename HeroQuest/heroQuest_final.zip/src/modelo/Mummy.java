package modelo;

public class Mummy extends Monster {
	
	private static final long serialVersionUID = -5564740521404008156L;

	public Mummy() {
		super(2, 0, 3, 4);
	}
}