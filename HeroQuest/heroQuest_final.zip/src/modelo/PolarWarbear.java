package modelo;

public class PolarWarbear extends Monster {
	
	private static final long serialVersionUID = -103377355751492653L;

	public PolarWarbear() {
		super(6, 2, 4, 3);
	}
}