package modelo;

public class Room extends Position {
	
	private static final long serialVersionUID = -2514265334681042323L;

	public Room(int row, int column) {
		super(row, column);
	}
}