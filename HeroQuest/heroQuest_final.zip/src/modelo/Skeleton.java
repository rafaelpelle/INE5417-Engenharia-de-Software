package modelo;

public class Skeleton extends Monster {
	
	private static final long serialVersionUID = -733776340101124332L;

	public Skeleton() {
		super(1, 0, 2, 2);
	}

}
