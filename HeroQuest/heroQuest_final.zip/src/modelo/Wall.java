package modelo;

public class Wall extends Position {
	
	private static final long serialVersionUID = 4412919627091565846L;

	public Wall(int row, int column) {
		super(row, column);
	}
}