package modelo;

public class Zombie extends Monster {
	
	private static final long serialVersionUID = 7641094864205757044L;

	public Zombie() {
		super(1, 0, 2, 3);
	}
	
}